-- Banco de dados: CEAP 2025
-- Execute este arquivo no MySQL Workbench antes de importar o CSV tratado.
CREATE DATABASE IF NOT EXISTS ceap_2025
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ceap_2025;

DROP TABLE IF EXISTS despesas_ceap;
CREATE TABLE despesas_ceap (
  `txNomeParlamentar` VARCHAR(150) NULL,
  `cpf` VARCHAR(20) NULL,
  `ideCadastro` BIGINT NULL,
  `nuCarteiraParlamentar` INT NULL,
  `nuLegislatura` INT NULL,
  `sgUF` CHAR(2) NULL,
  `sgPartido` VARCHAR(30) NULL,
  `codLegislatura` INT NULL,
  `numSubCota` INT NULL,
  `txtDescricao` VARCHAR(255) NULL,
  `numEspecificacaoSubCota` INT NULL,
  `txtDescricaoEspecificacao` VARCHAR(255) NULL,
  `txtFornecedor` VARCHAR(255) NULL,
  `txtCNPJCPF` VARCHAR(30) NULL,
  `txtNumero` VARCHAR(100) NULL,
  `indTipoDocumento` INT NULL,
  `datEmissao` DATE NULL,
  `vlrDocumento` DECIMAL(15,2) NULL,
  `vlrGlosa` DECIMAL(15,2) NULL,
  `vlrLiquido` DECIMAL(15,2) NULL,
  `numMes` TINYINT NULL,
  `numAno` SMALLINT NULL,
  `numParcela` INT NULL,
  `txtPassageiro` VARCHAR(255) NULL,
  `txtTrecho` VARCHAR(255) NULL,
  `numLote` BIGINT NULL,
  `numRessarcimento` BIGINT NULL,
  `datPagamentoRestituicao` DATE NULL,
  `vlrRestituicao` DECIMAL(15,2) NULL,
  `nuDeputadoId` BIGINT NULL,
  `ideDocumento` BIGINT NULL,
  `urlDocumento` VARCHAR(500) NULL,
  `indicador_outlier_valor` TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- IMPORTAÇÃO PELO MYSQL WORKBENCH (recomendado):
-- 1. Execute este arquivo inteiro (ícone de raio).
-- 2. Em Schemas > ceap_2025 > Tables, botão direito > Table Data Import Wizard.
-- 3. Selecione data/processed/CEAP_2025_tratada.csv.
-- 4. Delimiter: ;  |  Encoding: utf-8 | First row contains column names.
-- 5. Escolha a tabela existente despesas_ceap e confirme o mapeamento das 33 colunas.
-- 6. Ao concluir, valide com: SELECT COUNT(*) FROM despesas_ceap; (esperado: 171059)
-- IMPORTANTE: não use DROP TABLE depois de importar, pois apagará os dados.
