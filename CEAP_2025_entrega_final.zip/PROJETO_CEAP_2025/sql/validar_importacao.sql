USE ceap_2025;

-- 1. Quantidade de registros: esperado 171059
SELECT COUNT(*) AS total_registros FROM despesas_ceap;

-- 2. Total financeiro líquido
SELECT ROUND(SUM(vlrLiquido), 2) AS total_liquido FROM despesas_ceap;

-- 3. Quantidade de registros sinalizados como outliers
SELECT COUNT(*) AS registros_sinalizados
FROM despesas_ceap
WHERE indicador_outlier_valor = 1;

-- 4. Distribuição por UF
SELECT sgUF, COUNT(*) AS quantidade, ROUND(SUM(vlrLiquido), 2) AS total_liquido
FROM despesas_ceap
GROUP BY sgUF
ORDER BY total_liquido DESC;

-- 5. Verificação de valores ausentes em campos-chave
SELECT
  SUM(txNomeParlamentar IS NULL OR txNomeParlamentar = '') AS sem_parlamentar,
  SUM(txtDescricao IS NULL OR txtDescricao = '') AS sem_categoria,
  SUM(vlrLiquido IS NULL) AS sem_valor_liquido
FROM despesas_ceap;
