"""Gera a análise exploratória e o dashboard estático da CEAP 2025."""
from pathlib import Path
from html import escape
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "raw" / "Ano-2025.csv"
GRAPHICS = ROOT / "graphics"
DASHBOARD = ROOT / "dashboard"

MESES = {1: "Jan", 2: "Fev", 3: "Mar", 4: "Abr", 5: "Mai", 6: "Jun",
         7: "Jul", 8: "Ago", 9: "Set", 10: "Out", 11: "Nov", 12: "Dez"}

def moeda(valor):
    return ("R$ {:,.2f}".format(float(valor))).replace(",", "X").replace(".", ",").replace("X", ".")

def carregar_dados():
    df = pd.read_csv(DATA_FILE, sep=";", encoding="utf-8", low_memory=False)
    df["vlrLiquido"] = pd.to_numeric(df["vlrLiquido"], errors="coerce")
    df["numMes"] = pd.to_numeric(df["numMes"], errors="coerce")
    return df

def gerar_graficos(df):
    GRAPHICS.mkdir(exist_ok=True)
    categorias = df.groupby("txtDescricao")["vlrLiquido"].sum().sort_values(ascending=False).head(8).sort_values()
    fig, ax = plt.subplots(figsize=(10, 4.6))
    ax.barh(categorias.index.astype(str).str.slice(0, 48), categorias.values)
    ax.set_title("Maiores valores líquidos por tipo de despesa")
    ax.set_xlabel("Valor líquido (R$)")
    ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, pos: f"R$ {x/1e6:.1f} mi"))
    fig.tight_layout(); fig.savefig(GRAPHICS / "categorias_despesa.png", dpi=130); plt.close(fig)

    mensal = df.groupby("numMes")["vlrLiquido"].sum().reindex(range(1, 13), fill_value=0)
    fig, ax = plt.subplots(figsize=(10, 4.2))
    ax.bar([MESES[m] for m in mensal.index], mensal.values)
    ax.set_title("Soma dos valores líquidos por mês")
    ax.set_ylabel("Valor líquido (R$)")
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, pos: f"R$ {x/1e6:.1f} mi"))
    fig.tight_layout(); fig.savefig(GRAPHICS / "total_mensal.png", dpi=130); plt.close(fig)

def gerar_dashboard(df):
    valores = df["vlrLiquido"].dropna()
    media, moda, mediana = valores.mean(), valores.mode().iloc[0], valores.median()
    desvio, variancia = valores.std(), valores.var()
    top = df.groupby("txtDescricao")["vlrLiquido"].sum().sort_values(ascending=False).head(8)
    faltantes = df.isna().sum().sort_values(ascending=False).head(8)
    tipos = [
        ("Categórica nominal", "sgUF, sgPartido, txtDescricao, txtFornecedor"),
        ("Categórica ordinal", "Não foi identificada uma variável ordinal evidente."),
        ("Numérica discreta", "numMes, numAno, numLote, nuDeputadoId"),
        ("Numérica contínua", "vlrDocumento, vlrGlosa, vlrLiquido, vlrRestituicao"),
    ]
    tipos_html = "".join(f"<tr><td>{escape(a)}</td><td>{escape(b)}</td></tr>" for a,b in tipos)
    top_html = "".join(f"<tr><td>{escape(str(k).strip())}</td><td>{moeda(v)}</td></tr>" for k,v in top.items())
    faltantes_html = "".join(f"<tr><td>{escape(str(k))}</td><td>{int(v):,}</td></tr>".replace(",", ".") for k,v in faltantes.items())
    critica = (f"A base possui {len(df):,} registros e {len(df.columns)} colunas. "
               f"A soma dos valores líquidos é {moeda(valores.sum())}. A média por registro é {moeda(media)}, "
               f"e a mediana é {moeda(mediana)}. A média é maior que a mediana e o desvio padrão é {moeda(desvio)}, "
               "indicando variação considerável entre os valores e a presença de registros altos. "
               f"A moda é {moeda(moda)}. Existem campos com valores ausentes; alguns podem não se aplicar a todos os registros. "
               "Os dados, isoladamente, não comprovam irregularidades. É necessário verificar documentos e contexto.")
    stats = [("Média",moeda(media)),("Moda",moeda(moda)),("Mediana",moeda(mediana)),
             ("Desvio padrão",moeda(desvio)),("Variância",f"{variancia:,.2f}"),
             ("Mínimo",moeda(valores.min())),("Máximo",moeda(valores.max()))]
    stats_html = "".join(f"<tr><th>{k}</th><td>{v}</td></tr>" for k,v in stats)
    template = (DASHBOARD/"templates"/"index.html").read_text(encoding="utf-8")
    html = template.replace("{{REGISTROS}}",f"{len(df):,}").replace("{{COLUNAS}}",str(len(df.columns)))
    html = html.replace("{{TOTAL}}",moeda(valores.sum())).replace("{{VAZIOS}}",f"{int(df.isna().sum().sum()):,}")
    html = html.replace("{{TIPOS}}",tipos_html).replace("{{ESTATISTICAS}}",stats_html)
    html = html.replace("{{TOP}}",top_html).replace("{{FALTANTES}}",faltantes_html).replace("{{CRITICA}}",escape(critica))
    (DASHBOARD/"index.html").write_text(html,encoding="utf-8")

def executar():
    df=carregar_dados()
    gerar_graficos(df)
    gerar_dashboard(df)
    print(f"Dashboard gerado em: {DASHBOARD / 'index.html'}")
    print(f"Registros: {len(df)} | Colunas: {len(df.columns)}")

if __name__ == "__main__":
    executar()
