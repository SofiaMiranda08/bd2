"""
Tratamento da base CEAP 2025.
Requisitos: pip install pandas numpy
Execute na pasta deste script. Aponte ARQUIVO_ORIGINAL para o CSV bruto.
"""
from pathlib import Path
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
ARQUIVO_ORIGINAL = ROOT / "data" / "raw" / "Ano-2025.csv"
SAIDA = ROOT / "data" / "processed" / "CEAP_2025_tratada.csv"

df = pd.read_csv(ARQUIVO_ORIGINAL, sep=";", encoding="utf-8", low_memory=False)

# 1) Padronização: espaços extras e textos vazios passam a valores ausentes.
for coluna in df.select_dtypes(include=["object"]).columns:
    df[coluna] = df[coluna].astype("string").str.strip().replace("", pd.NA)

# 2) Conversão de datas e campos numéricos.
for coluna in ["datEmissao", "datPagamentoRestituicao"]:
    df[coluna] = pd.to_datetime(df[coluna], errors="coerce").dt.strftime("%Y-%m-%d").astype("string")

for coluna in df.columns:
    if coluna.startswith(("vlr", "num", "ide", "nu", "cod", "ind")):
        df[coluna] = pd.to_numeric(df[coluna], errors="coerce")

# 3) Duplicidades: remover somente linhas integralmente duplicadas.
qtd_duplicadas = int(df.duplicated().sum())
df = df.drop_duplicates()

# 4) Outliers: regra IQR nos campos monetários.
# Não excluir nem limitar valores: sinalizar para análise, pois despesas altas,
# glosas e estornos podem ser registros legítimos.
mascaras = []
for coluna in ["vlrDocumento", "vlrGlosa", "vlrLiquido", "vlrRestituicao"]:
    serie = df[coluna].dropna()
    if serie.empty:
        continue
    q1, q3 = serie.quantile([0.25, 0.75])
    iqr = q3 - q1
    limite_inferior = q1 - 1.5 * iqr
    limite_superior = q3 + 1.5 * iqr
    mascaras.append(df[coluna].notna() & (
        (df[coluna] < limite_inferior) | (df[coluna] > limite_superior)
    ))

df["indicador_outlier_valor"] = (
    np.logical_or.reduce([m.to_numpy() for m in mascaras]).astype("int8")
    if mascaras else 0
)

df.to_csv(SAIDA, index=False, sep=";", encoding="utf-8-sig", na_rep="")
print(f"Base tratada gerada: {SAIDA}")
print(f"Registros: {len(df):,}")
print(f"Duplicidades exatas removidas: {qtd_duplicadas:,}")
print(f"Registros sinalizados como outlier: {int(df['indicador_outlier_valor'].sum()):,}")
