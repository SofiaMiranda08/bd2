"""Ponto de entrada da análise exploratória CEAP 2025."""
from analysis import executar

if __name__ == "__main__":
    executar()
