# Projeto CEAP 2025

## Execução local (Windows)
1. Extraia o ZIP.
2. Abra a pasta no VS Code.
3. Instale dependências: `python -m pip install -r requirements.txt`
4. Dê duplo clique em `iniciar_dashboard.bat` (ou execute pelo terminal).
5. O navegador abrirá em http://127.0.0.1:8000. Mantenha a janela do terminal aberta.

O dashboard utiliza `dashboard/static/data/ceap.json`, gerado a partir de `data/processed/CEAP_2025_tratada.csv`. Não abra `dashboard/index.html` diretamente: o navegador bloqueia o carregamento local do JSON.

## MySQL Workbench
1. Abra `sql/criar_banco_ceap_2025.sql` e execute tudo.
2. Em Schemas > ceap_2025 > Tables, clique com o botão direito e escolha **Table Data Import Wizard**.
3. Importe `data/processed/CEAP_2025_tratada.csv`, separador `;`, UTF-8, primeira linha com nomes de colunas.
4. Selecione a tabela existente `despesas_ceap`, confira o mapeamento das 33 colunas e conclua.
5. Valide: `SELECT COUNT(*) FROM ceap_2025.despesas_ceap;` Resultado esperado: 171059.

## Conteúdo
- `data/raw/`: CSV original.
- `data/processed/`: CSV tratado para importação.
- `dashboard/`: dashboard interativo estático (filtros, KPIs, gráficos e tabela).
- `dashboard/static/data/ceap.json`: dados compactados para o dashboard.
- `src/treatment.py`: tratamento da base.
- `sql/`: criação do banco e tabela.
- `reports/` e `graphics/`: materiais da análise exploratória anterior.

## Critérios do tratamento
- Ausências textuais padronizadas; não são inventados valores.
- Remoção somente de duplicatas integrais.
- Outliers identificados pela regra IQR e sinalizados, sem exclusão automática.
