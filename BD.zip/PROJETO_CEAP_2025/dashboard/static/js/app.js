// Reservado para a etapa 2: filtros e interatividade do dashboard.
