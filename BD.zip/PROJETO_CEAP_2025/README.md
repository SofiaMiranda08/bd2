# Projeto CEAP 2025 — Análise Exploratória

Projeto organizado para reproduzir a entrega da primeira aula e evoluir, em etapa separada, para tratamento de dados, MySQL e dashboard interativo.

## Estrutura
- `data/raw/`: base original da Câmara dos Deputados.
- `data/processed/`: base tratada da atividade seguinte.
- `src/`: código Python separado por responsabilidade.
- `dashboard/templates/`: estrutura HTML.
- `dashboard/static/css/`: estilos CSS.
- `dashboard/static/js/`: reservado para a interatividade da etapa 2.
- `graphics/`: gráficos gerados.
- `reports/`: relatório da primeira aula.
- `sql/`: script de criação do banco MySQL.

## Executar a primeira aula
1. Instale Python 3.10 ou superior.
2. Abra o terminal na pasta raiz `PROJETO_CEAP_2025`.
3. (Recomendado) Crie um ambiente virtual: `python -m venv .venv`.
4. Ative o ambiente virtual e instale: `python -m pip install -r requirements.txt`.
5. Execute: `python src/main.py`.
6. Abra `dashboard/index.html` no navegador.

## Etapa 2 — tratamento e MySQL
Execute `python src/treatment.py` para regenerar `data/processed/CEAP_2025_tratada.csv`.
O script SQL está em `sql/criar_banco_ceap_2025.sql`. A importação no MySQL Workbench será validada separadamente.

## Observação
O dashboard desta primeira versão reproduz a análise exploratória e é estático. Filtros e interações serão implementados somente após a validação desta versão.
